package com.example.springapp.cpuloader;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CpuLoaderApplicationTests {

	@Test
	void contextLoads() {
	}

}
