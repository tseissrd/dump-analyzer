package com.example.springapp.cpuloader;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CpuLoaderApplication {

	public static void main(String[] args) {
		SpringApplication.run(CpuLoaderApplication.class, args);
	}

}
